In this directory you find the first version of the D64 tool created by CHATGPT.
The chat history is here as a PDF as well.

Further improvements, have been made manually, and cannot be found in the chat.